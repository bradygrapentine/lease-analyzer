# LeaseGuard replay bundle

Lease: **sample-residential.pdf**
Rule pack version: `1.0.0`
Expected findings: 2

## Contents

- `lease.pdf` — original lease PDF
- `pack.lgpack.json` — serialized rule pack(s) used to produce the expected findings
- `expected.json` — findings JSON, schema `leaseguard.findings.v1`
- `replay.mjs` — Node helper that validates the bundle and prints next steps
- `README.md` — this file

## How to replay

1. Run `node replay.mjs` to sanity-check the bundle.
2. Open the LeaseGuard app (or a fresh build from source at the same
   rule pack version).
3. Import `pack.lgpack.json` via **Rule Packs → Import**.
4. Analyze `lease.pdf` and compare the output JSON to `expected.json`.

The `expected.json` schema id is `leaseguard.findings.v1`. Each finding
carries a `rulePackVersion` stamp so drift between runs is detectable.
