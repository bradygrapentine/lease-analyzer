#!/usr/bin/env node
// LeaseGuard replay bundle — tiny local loader.
// Usage:
//   node replay.mjs
// This script only validates that the bundle is intact and prints next
// steps. To actually re-run the rules, load pack.lgpack.json into the
// LeaseGuard app (Rule Packs → Import) with lease.pdf, and diff the
// result against expected.json.
import { readFile } from 'node:fs/promises';

const pdf = await readFile(new URL('./lease.pdf', import.meta.url));
const pack = JSON.parse(await readFile(new URL('./pack.lgpack.json', import.meta.url), 'utf8'));
const expected = JSON.parse(await readFile(new URL('./expected.json', import.meta.url), 'utf8'));

console.log('lease.pdf bytes:', pdf.byteLength);
console.log('rule pack version:', expected.rulePackVersion);
console.log('expected findings:', expected.findings.length);
console.log('pack id(s):', Array.isArray(pack) ? pack.map((p) => p.id).join(', ') : pack.id);
console.log('\nNext: import pack.lgpack.json into the LeaseGuard app, analyze lease.pdf,');
console.log('and compare the output to expected.json (schema leaseguard.findings.v1).');
